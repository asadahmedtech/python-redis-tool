import sys

from cli import redis_tool


def main():
    redis_tool.main()


if __name__ == "__main__":
    main()
